package com.ecommerce.app.service;

import com.ecommerce.app.entity.Cart;
import com.ecommerce.app.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartRepository repo;

    // Add to cart
    public Cart addToCart(Cart cart) {
        return repo.save(cart);
    }

    // Get cart by user
    public List<Cart> getCartDetails(Long userId) {
        return repo.findByUser_UserId(userId);
    }

    // Remove item
    public void removeFromCart(Long cartId) {
        repo.deleteById(cartId);
    }

    // Clear cart after order
    public void clearCart() {
        repo.deleteAll();
    }
}