package com.ecommerce.app.service;

import com.ecommerce.app.entity.*;
import com.ecommerce.app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepo;

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private ProductRepository productRepo;

    // Process Payment
    public Payment processPayment(Long orderId) {

        Order order = orderRepo.findById(orderId).orElseThrow();

        // Check stock
        for (OrderItem item : order.getItems()) {

            Product product = item.getProduct();

            if (product.getStockQuantity() < item.getQuantity()) {
                throw new RuntimeException("Insufficient stock");
            }

            product.setStockQuantity(
                    product.getStockQuantity() - item.getQuantity()
            );

            productRepo.save(product);
        }

        // Create payment
        Payment payment = new Payment();
        payment.setOrder(order);
        payment.setAmount(order.getTotalAmount());
        payment.setPaymentStatus("COMPLETED");
        payment.setPaymentDate(LocalDate.now());

        // Update order
        order.setStatus("DELIVERED");
        orderRepo.save(order);

        return paymentRepo.save(payment);
    }

    public Payment getPaymentStatus(Long paymentId) {
        return paymentRepo.findById(paymentId).orElseThrow();
    }
}
