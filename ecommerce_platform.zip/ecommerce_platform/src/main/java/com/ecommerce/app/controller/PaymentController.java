package com.ecommerce.app.controller;

import com.ecommerce.app.entity.Payment;
import com.ecommerce.app.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
@CrossOrigin("*")
public class PaymentController {

    @Autowired
    private PaymentService service;

    // Process payment
    @PostMapping("/{orderId}")
    public Payment processPayment(@PathVariable Long orderId) {
        return service.processPayment(orderId);
    }

    // Get payment status
    @GetMapping("/{paymentId}")
    public Payment getStatus(@PathVariable Long paymentId) {
        return service.getPaymentStatus(paymentId);
    }
}