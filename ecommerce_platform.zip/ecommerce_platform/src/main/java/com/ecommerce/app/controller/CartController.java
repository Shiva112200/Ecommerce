package com.ecommerce.app.controller;

import com.ecommerce.app.entity.Cart;
import com.ecommerce.app.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cart")
@CrossOrigin("*")
public class CartController {

    @Autowired
    private CartService service;

    // Add to cart
    @PostMapping
    public Cart addToCart(@RequestBody Cart cart) {
        return service.addToCart(cart);
    }

    // Get cart by user
    @GetMapping("/{userId}")
    public List<Cart> getCart(@PathVariable Long userId) {
        return service.getCartDetails(userId);
    }

    // Remove item
    @DeleteMapping("/{cartId}")
    public String removeItem(@PathVariable Long cartId) {
        service.removeFromCart(cartId);
        return "Item removed from cart";
    }
}
