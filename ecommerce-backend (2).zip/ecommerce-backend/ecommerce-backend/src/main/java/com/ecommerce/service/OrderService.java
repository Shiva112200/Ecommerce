package com.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.Order;
import com.ecommerce.entity.Cart;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.repository.CartRepository;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartRepository cartRepository;

    // Place Order (from cart)
    public String placeOrder() {

        List<Cart> cartItems = cartRepository.findAll();

        if(cartItems.isEmpty()) {
            return "Cart is empty";
        }

        for(Cart cart : cartItems) {

            Order order = new Order();
            order.setProductId(cart.getProductId());
            order.setProductName(cart.getProductName());
            order.setQuantity(cart.getQuantity());
            order.setTotalPrice(cart.getPrice() * cart.getQuantity());
            order.setStatus("PENDING");

            orderRepository.save(order);
        }

        cartRepository.deleteAll();

        return "Order Placed Successfully";
    }

    // Get all orders
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
}