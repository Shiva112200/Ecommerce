package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.entity.Cart;
import com.ecommerce.service.CartService;

@RestController
@RequestMapping("/cart")
@CrossOrigin("*")
public class CartController {

    @Autowired
    private CartService service;

    // Add To Cart
    @PostMapping
    public Cart addToCart(@RequestBody Cart cart) {
        return service.addToCart(cart);
    }

    // Get Cart Items
    @GetMapping
    public List<Cart> getCartItems() {
        return service.getCartItems();
    }

    // Remove Cart Item
    @DeleteMapping("/{id}")
    public String removeCartItem(@PathVariable Long id) {
        return service.removeCartItem(id);
    }
}