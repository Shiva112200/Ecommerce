package com.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.Cart;
import com.ecommerce.repository.CartRepository;

@Service
public class CartService {

    @Autowired
    private CartRepository repository;

    // Add Item To Cart
    public Cart addToCart(Cart cart) {
        return repository.save(cart);
    }

    // Get All Cart Items
    public List<Cart> getCartItems() {
        return repository.findAll();
    }

    // Remove Cart Item
    public String removeCartItem(Long id) {
        repository.deleteById(id);
        return "Item Removed From Cart";
    }
}